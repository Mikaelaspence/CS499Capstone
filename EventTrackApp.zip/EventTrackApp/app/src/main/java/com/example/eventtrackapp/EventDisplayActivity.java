package com.example.eventtrackapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.eventtrackapp.controller.EventController;

import java.util.ArrayList;

public class EventDisplayActivity extends AppCompatActivity {

    private GridView gridView;
    private Button addEventButton;
    private EventController eventController;
    private ArrayList<String> eventList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_display);

        gridView = findViewById(R.id.event_grid);
        addEventButton = findViewById(R.id.add_event_button);

        eventController = new EventController(this);
        eventList = new ArrayList<>();
        loadEventData();

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, eventList);
        gridView.setAdapter(adapter);

        addEventButton.setOnClickListener(v -> showEventDialog(null, -1));

        gridView.setOnItemClickListener((parent, view, position, id) -> showEventDialog(eventList.get(position), position));
    }

    private void loadEventData() {
        eventList.clear();
        eventList.addAll(eventController.getAllEvents());
        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }
    }

    private void showEventDialog(String eventData, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(eventData == null ? "Add Event" : "Edit Event");

        View viewInflated = getLayoutInflater().inflate(R.layout.dialog_add_event, null);
        EditText inputName = viewInflated.findViewById(R.id.input_event_name);
        EditText inputDate = viewInflated.findViewById(R.id.input_event_date);

        int eventId = -1;
        if (eventData != null) {
            String[] parts = eventData.split(" - ");
            inputName.setText(parts[0]);
            inputDate.setText(parts[1]);
            eventId = eventController.getEventIdByPosition(position);
        }

        builder.setView(viewInflated);
        final int finalEventId = eventId;

        builder.setPositiveButton(eventData == null ? "Add" : "Update", (dialog, which) -> {
            String eventName = inputName.getText().toString();
            String eventDate = inputDate.getText().toString();

            if (eventData == null) {
                if (eventController.addEvent(eventName, eventDate)) {
                    Toast.makeText(EventDisplayActivity.this, "Event added", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EventDisplayActivity.this, SMSNotificationsActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(EventDisplayActivity.this, "Failed to add event", Toast.LENGTH_SHORT).show();
                }
            } else {
                if (eventController.updateEvent(finalEventId, eventName, eventDate)) {
                    Toast.makeText(EventDisplayActivity.this, "Event updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(EventDisplayActivity.this, "Failed to update event", Toast.LENGTH_SHORT).show();
                }
            }
            loadEventData();
        });

        builder.setNegativeButton(eventData == null ? "Cancel" : "Delete", (dialog, which) -> {
            if (eventData != null) {
                if (eventController.deleteEvent(finalEventId)) {
                    Toast.makeText(EventDisplayActivity.this, "Event deleted", Toast.LENGTH_SHORT).show();
                    loadEventData();
                } else {
                    Toast.makeText(EventDisplayActivity.this, "Failed to delete event", Toast.LENGTH_SHORT).show();
                }
            }
            dialog.dismiss();
        });

        builder.show();
    }
}

package com.example.eventtrackapp.controller;

import android.content.Context;
import com.example.eventtrackapp.DatabaseHelper;
import java.util.ArrayList;

public class EventController {
    private DatabaseHelper databaseHelper;

    public EventController(Context context) {
        this.databaseHelper = new DatabaseHelper(context);
    }

    public boolean checkUser(String username, String password) {
        return databaseHelper.checkUser(username, password);
    }

    public ArrayList<String> getAllEvents() {
        return databaseHelper.getAllEvents();
    }

    public boolean addEvent(String eventName, String eventDate) {
        return databaseHelper.addEvent(eventName, eventDate);
    }

    public boolean updateEvent(int eventId, String eventName, String eventDate) {
        return databaseHelper.updateEvent(eventId, eventName, eventDate);
    }

    public boolean deleteEvent(int eventId) {
        return databaseHelper.deleteEvent(eventId);
    }

    public int getEventIdByPosition(int position) {
        return databaseHelper.getEventIdByPosition(position);
    }
}
